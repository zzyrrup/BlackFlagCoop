#include "logger.h"
#include "splash.h"

#include <Windows.h>

#include <string>

namespace {

constexpr const char* kPluginVersion = "0.2.0";

}  // namespace

// Ultimate ASI Loader calls this after LoadLibrary, outside the loader lock.
// Keep real startup work here — not inside DllMain.
extern "C" __declspec(dllexport) void InitializeASI() {
    if (!bfc::Logger::Initialize()) {
        return;
    }

    const DWORD processId = GetCurrentProcessId();
    const std::string timestamp = bfc::Logger::FormatLocalTimestamp();

    bfc::Logger::Info("Plugin initialization successful");
    bfc::Logger::Info(std::string("Plugin version ") + kPluginVersion);
    bfc::Logger::Info("Process ID " + std::to_string(static_cast<unsigned long long>(processId)));
    bfc::Logger::Info("Initialization timestamp " + timestamp);

    if (bfc::StartSplashScreen()) {
        bfc::Logger::Info("Startup splash requested");
    } else {
        bfc::Logger::Info("Startup splash could not be started");
    }
}

// Keep DllMain minimal. Do not open files, create threads, or load other DLLs here.
BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID reserved) {
    (void)reserved;

    switch (reason) {
    case DLL_PROCESS_ATTACH:
        // Disable thread attach/detach notifications; we do not need them.
        DisableThreadLibraryCalls(module);
        break;

    default:
        break;
    }

    return TRUE;
}
